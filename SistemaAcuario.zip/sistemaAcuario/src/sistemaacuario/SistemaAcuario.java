/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sistemaacuario;

/**
 *
 * @author maxim
 */
public class SistemaAcuario {
    public static void main(String[] args) {
        
        Acuario acuario = new Acuario();

        try {
            acuario.agregarEspecie(new Peces("Pez Payaso", "Tanque 1", TipoAgua.AGUA_SALADA, 12.5));
            acuario.agregarEspecie(new Mosluscos("Caracol Marino", "Tanque 2", TipoAgua.AGUA_SALADA, "Espiralada"));
            acuario.agregarEspecie(new Corales("Coral Rojo", "Tanque 3", TipoAgua.AGUA_SALADA, 15.0));
            acuario.agregarEspecie(new Peces("Tetra", "Tanque 4", TipoAgua.AGUA_DULCE, 4.0));

            // Intentar duplicado
            // acuario.agregarEspecie(new Pez("Pez Payaso", "Tanque 1", TipoAgua.AGUA_SALADA, 11.0));

        } catch (ExepcionDeDuplicado e) {
            System.out.println("Error: " + e.getMessage());
        }

        System.out.println();
        acuario.mostrarEspecies();

        System.out.println();
        acuario.alimentarEspecies();

        System.out.println();
        acuario.filtrarPorTipoAgua(TipoAgua.AGUA_DULCE);
    }
    
}
