/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemaacuario;

/**
 *
 * @author maxim
 */
public class Mosluscos extends EspeciesMarinas implements Alimentable{
    private String tipoConcha;

    public Mosluscos( String nombre, String tanque, TipoAgua tipoAgua, String tipoConcha) {
        super(nombre, tanque, tipoAgua);
        this.tipoConcha = tipoConcha;
    }
    
    
    @Override
    public void alimentar(){
        System.out.println( nombre + " alimentado");
    }
    
     @Override
    public String getInfo() {
        return "Molusco - Nombre: " + nombre + ", Tanque: " + tanque +
               ", Agua: " + tipoAgua + ", Concha: " + tipoConcha;
    }
    
    
    
}
