/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemaacuario;

/**
 *
 * @author maxim
 */
public abstract class EspeciesMarinas{
    protected String nombre;
    protected String tanque;
    protected TipoAgua tipoAgua;

    public EspeciesMarinas(String nombre, String tanque, TipoAgua tipoAgua) {
        this.nombre = nombre;
        this.tanque = tanque;
        this.tipoAgua = tipoAgua;
    }

    public String getNombre() {
        return nombre;
    }

    public String getTanque() {
        return tanque;
    }

    public TipoAgua getTipoAgua() {
        return tipoAgua;
    }

    public abstract String getInfo();
    
    
    public void respirar() {
        System.out.println(this.getNombre() + "respirando");                
    }
    
    public void reproducirse() {
        System.out.println(this.getNombre() + "reproduciendose");
    }
    
    
}
