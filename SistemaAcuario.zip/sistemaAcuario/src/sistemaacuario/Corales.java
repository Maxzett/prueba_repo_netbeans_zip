/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemaacuario;

/**
 *
 * @author maxim
 */
public class Corales extends EspeciesMarinas {
    private double profundidadCrecimiento;

    public Corales( String nombre, String tanque, TipoAgua tipoAgua, double profundidadCrecimiento) {
        super(nombre, tanque, tipoAgua);
        this.profundidadCrecimiento = profundidadCrecimiento;
    }
    
    
    
     @Override
    public String getInfo() {
         return "Coral - Nombre: " + nombre + ", Tanque: " + tanque + ", Agua: " + tipoAgua + ", Profundidad Ideal: " + profundidadCrecimiento + " m";
    }
    
    
    
}
