/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemaacuario;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author maxim
 */
public class Acuario {
    private List<EspeciesMarinas> especies;
    
    public Acuario() {
        especies = new ArrayList<>();
    }
    
    
    public void agregarEspecie(EspeciesMarinas especie) throws ExepcionDeDuplicado{
        for(EspeciesMarinas e: especies){
            if(e.getNombre().equalsIgnoreCase(especie.getNombre()) && e.getTanque().equalsIgnoreCase(especie.getTanque())){
                throw new ExepcionDeDuplicado("Ya existe esta especie");
            }            
        }
        especies.add(especie);
    }
    
    public void mostrarEspecies(){
        for(EspeciesMarinas e : especies){
            e.getInfo();
        }
    }
    
    public void alimentarEspecies() {
        System.out.println("=== Alimentando especies ===");
        for (EspeciesMarinas e : especies) {
            if (e instanceof Alimentable a) {
                //((Alimentable) e).alimentar();
                a.alimentar();
            } else {
                System.out.println(e.getNombre() + " no puede ser alimentado.");
            }
        }
    }
    
    public void filtrarPorTipoAgua(TipoAgua tipo) {
        System.out.println("=== Especies en " + tipo + " ===");
        for (EspeciesMarinas e : especies) {
            if (e.getTipoAgua() == tipo) {
                System.out.println(e.getInfo());
            }
        }
    }
    
    
}
