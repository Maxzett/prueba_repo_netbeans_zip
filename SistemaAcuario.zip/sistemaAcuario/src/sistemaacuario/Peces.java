/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemaacuario;

/**
 *
 * @author maxim
 */
public class Peces extends EspeciesMarinas implements Alimentable{
    private double longitudMax;

    public Peces(String nombre, String tanque, TipoAgua tipoAgua, double longitudMax) {
        super(nombre, tanque, tipoAgua);
        this.longitudMax = longitudMax;
    }

    @Override
    public void alimentar(){
        System.out.println( this.getNombre()+ " alimentado");
    }
    

    @Override
    public String getInfo() {
        return "Pez - Nombre: " + nombre + ", Tanque: " + tanque +
               ", Agua: " + tipoAgua + ", Longitud Máx: " + longitudMax + " cm";
    }

    
}
